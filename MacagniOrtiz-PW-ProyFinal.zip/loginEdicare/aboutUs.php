<?php
  //separo header de lo que contenga el medio de la pantalla
  require "header.php";
?>
<br>
<br>
   <link rel="stylesheet" href="style.css">
<p class="login-titulo">Que es Edicare?</p>
<br>
<br>
<br>

<p class="login-subtituloAU">Edicare es un sistema online creado con el objetivo de facilitar todo tipo de tramites rutinarios que tienen que ver con la administracion de edificios o condominios y las gestiones que se realizan dentro de este. Nuestro fin es brindar una comodidad extra al propietario / inquilino utilizando este sistema, evitando vias de comunicacion incomodas, pero sobretodo facilitar el trabajo del administrador creando una via de comunicacion directa con cada persona. </p>